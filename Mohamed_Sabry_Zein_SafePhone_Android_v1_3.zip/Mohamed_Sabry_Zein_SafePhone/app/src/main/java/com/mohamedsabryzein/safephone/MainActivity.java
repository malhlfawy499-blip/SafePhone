package com.mohamedsabryzein.safephone;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.widget.*;
import java.io.File;
import java.util.List;

public class MainActivity extends Activity {
    private TextView status, result, permissionState;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.statusText);
        result=findViewById(R.id.resultText);
        permissionState=findViewById(R.id.permissionState);

        findViewById(R.id.startProtection).setOnClickListener(v -> startProtection());
        findViewById(R.id.scanButton).setOnClickListener(v -> scanApps());
        findViewById(R.id.fileButton).setOnClickListener(v -> chooseFile());
        findViewById(R.id.settingsButton).setOnClickListener(v -> openSecuritySettings());
        findViewById(R.id.cleanButton).setOnClickListener(v -> cleanOwnCache());
    }

    private void startProtection() {
        permissionState.setText("✓ تم تفعيل منظومة الحماية الأساسية داخل التطبيق.");
        status.setText("الحماية الأساسية جاهزة. لم نطلب صلاحيات لا نحتاجها.");
        Toast.makeText(this,"تم الدخول إلى منظومة محمد صبري للحماية",Toast.LENGTH_SHORT).show();
        scanApps();
    }

    private void scanApps() {
        status.setText("جاري تحليل التطبيقات والصلاحيات...");
        try {
            PackageManager pm=getPackageManager();
            List<PackageInfo> list=pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);
            int checked=0, warnings=0;
            StringBuilder details=new StringBuilder();
            for(PackageInfo p:list) {
                ApplicationInfo ai=p.applicationInfo;
                if(ai==null || (ai.flags & ApplicationInfo.FLAG_SYSTEM)!=0) continue;
                checked++;
                boolean suspicious=false;
                if(p.requestedPermissions!=null) {
                    for(String perm:p.requestedPermissions) {
                        if("android.permission.REQUEST_INSTALL_PACKAGES".equals(perm) ||
                           "android.permission.SYSTEM_ALERT_WINDOW".equals(perm) ||
                           "android.permission.READ_SMS".equals(perm)) { suspicious=true; break; }
                    }
                }
                if((ai.flags & ApplicationInfo.FLAG_DEBUGGABLE)!=0) suspicious=true;
                if(suspicious) {
                    warnings++;
                    CharSequence label=ai.loadLabel(pm);
                    details.append("⚠ ").append(label).append("\n");
                }
            }
            int score=Math.max(60,100-Math.min(warnings*5,40));
            status.setText("اكتمل الفحص.");
            result.setText("🛡️ نتيجة منظومة الحماية\n\nالدرجة: "+score+"/100\n"+
                    "التطبيقات التي تمت مراجعتها: "+checked+
                    "\nمؤشرات تحتاج مراجعة: "+warnings+
                    (warnings>0 ? "\n\nالتطبيقات التي تحتاج مراجعة:\n"+details : "\n\n✓ لم تظهر مؤشرات الصلاحيات المحددة في هذا الفحص.")+
                    "\n\nملاحظة: هذا تحليل أمني حقيقي للصلاحيات والخصائص التي يسمح Android بقراءتها، وليس محرك مكافحة برمجيات خبيثة كاملاً.");
        } catch(Exception e) {
            status.setText("تعذر إكمال الفحص.");
            result.setText("خطأ أثناء الفحص: "+e.getMessage());
        }
    }

    private void chooseFile() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,77);
    }

    @Override protected void onActivityResult(int r,int c,Intent data) {
        super.onActivityResult(r,c,data);
        if(r==77 && c==RESULT_OK && data!=null) {
            Uri u=data.getData();
            result.setText("📁 تم اختيار ملف للفحص:\n\n"+u+
                    "\n\nالملف أصبح متاحاً للتطبيق بموافقتك فقط. يمكن إضافة محرك بصمات/توقيعات للملفات في المرحلة التالية.");
        }
    }

    private void openSecuritySettings() {
        try { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); }
        catch(Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    private void cleanOwnCache() {
        long before=size(getCacheDir()); delete(getCacheDir());
        long freed=Math.max(0,before-size(getCacheDir()));
        result.setText("🧹 تم تنظيف Cache الخاص بالتطبيق فقط.\nالمساحة المحررة تقريباً: "+fmt(freed));
    }
    private void delete(File d){File[] a=d.listFiles();if(a==null)return;for(File f:a){if(f.isDirectory())delete(f);f.delete();}}
    private long size(File d){if(d==null||!d.exists())return 0;if(d.isFile())return d.length();long n=0;File[] a=d.listFiles();if(a!=null)for(File f:a)n+=size(f);return n;}
    private String fmt(long b){if(b<1024)return b+" B";double k=b/1024.0;if(k<1024)return String.format("%.1f KB",k);double m=k/1024.0;if(m<1024)return String.format("%.1f MB",m);return String.format("%.1f GB",m/1024.0);}
}