plugins {
    id("com.android.application")
}
android {
    namespace = "com.mohamedsabryzein.safephone"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.mohamedsabryzein.safephone"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "1.3.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}